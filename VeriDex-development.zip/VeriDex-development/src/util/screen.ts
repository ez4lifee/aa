export const isMobile = (width: number) => {
    return width < 480;
};
