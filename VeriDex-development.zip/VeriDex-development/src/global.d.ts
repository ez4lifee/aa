interface Window {
    ethereum: any;
    web3: any;
    __REDUX_DEVTOOLS_EXTENSION_COMPOSE__: any;
}

declare module 'react-copy-to-clipboard';
declare module 'react-tooltip';
declare module '*.json' {
    const value: any;
    export default value;
}

declare module '@walletconnect/web3-provider';
